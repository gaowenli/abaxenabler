#!/bin/sh

#################################################################
##
##  Usage:  # ./install.sh 
##
##  Execute the command as root or a sudo user
##
##  Exeray Inc, All Rights Reserved
##
#################################################################

echo
if [[ -w /usr/local/lib/ ]]; then
	echo "OK. Proceed with installation ..."
else
	echo "Error. Please execute the command as root or sudo user"
	echo
	exit 1
fi



/bin/rm -f /usr/local/lib/libabax.so
install -m 644 libabax.so /usr/local/lib
install -m 644 libabax.a /usr/local/lib

install -m 644 abaxenabler.h /usr/local/include

if [[ -x /sbin/ldconfig ]]; then
	/sbin/ldconfig
fi

if [[ -x /sbin/ldconfig ]]; then
	/sbin/ldconfig -p | grep abax
fi

/bin/ls -l /usr/local/include/abaxenabler.h
/bin/ls -l /usr/local/lib/libabax*
echo
echo "Installation successful"
echo

